import json
import os
import boto3
import requests

HF_API_KEY = os.environ["HF_API_KEY"]
USERS_TABLE = os.environ["USERS_TABLE"]
MEALPLANS_TABLE = os.environ["MEALPLANS_TABLE"]

dynamodb = boto3.resource("dynamodb")
users_table = dynamodb.Table(USERS_TABLE)
mealplans_table = dynamodb.Table(MEALPLANS_TABLE)

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "*",
    "Access-Control-Allow-Methods": "*"
}

def call_huggingface(prompt):
    url = "https://api-inference.huggingface.co/models/google/flan-t5-large"
    headers = {"Authorization": f"Bearer {HF_API_KEY}"}
    resp = requests.post(url, headers=headers, json={"inputs": prompt}, timeout=30)
    return resp.json()[0]["generated_text"]

def lambda_handler(event, context):
    try:
        user_id = event.get("requestContext", {}).get("authorizer", {}).get("claims", {}).get("sub")

        if not user_id:
            return {"statusCode": 401, "headers": CORS_HEADERS, "body": "Unauthorized"}

        pref = users_table.get_item(Key={"userId": user_id}).get("Item", {})
        diet = pref.get("diet", "regular")

        prompt = f"""
        Create a weekly meal plan for a user with "{diet}" diet.
        Output JSON with keys: Monday ... Sunday.
        Each day should include: breakfast, lunch, dinner.
        """

        generated = call_huggingface(prompt)

        mealplans_table.put_item(Item={"userId": user_id, "weekId": "latest", "plan": generated})

        return {
            "statusCode": 200,
            "headers": CORS_HEADERS,
            "body": generated
        }

    except Exception as e:
        return {"statusCode": 500, "headers": CORS_HEADERS, "body": json.dumps({"error": str(e)})}
