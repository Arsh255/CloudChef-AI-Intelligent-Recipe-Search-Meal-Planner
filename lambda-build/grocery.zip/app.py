import json
import os
import boto3

dynamodb = boto3.resource("dynamodb")
grocery_table = dynamodb.Table(os.environ["GROCERY_TABLE"])

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "*",
    "Access-Control-Allow-Methods": "*"
}

def lambda_handler(event, context):
    try:
        user_id = event.get("requestContext", {}).get("authorizer", {}).get("claims", {}).get("sub")
        body = json.loads(event.get("body", "{}"))

        meals = body.get("meals", [])

        merged = {}

        for item in meals:
            for ingredient in item.get("ingredients", []):
                name = ingredient["name"]
                qty = ingredient.get("qty", 1)

                merged[name] = merged.get(name, 0) + qty

        grocery_table.put_item(Item={
            "userId": user_id,
            "listId": "latest",
            "items": merged
        })

        return {
            "statusCode": 200,
            "headers": CORS_HEADERS,
            "body": json.dumps({"groceryList": merged})
        }

    except Exception as e:
        return {"statusCode": 500, "headers": CORS_HEADERS, "body": json.dumps({"error": str(e)})}
